// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    // Load featured courses on homepage
    if (document.getElementById('featured-courses')) {
        loadFeaturedCourses();
    }
    
    // Load all courses on courses page
    if (document.getElementById('courses-container')) {
        loadAllCourses();
        setupCourseFilters();
    }
    
    // Animate stats counter
    if (document.querySelector('.stats')) {
        animateStats();
    }
    
    // Setup mobile menu
    setupMobileMenu();
    
    // Setup course modal
    setupCourseModal();
});

// Load Featured Courses
async function loadFeaturedCourses() {
    try {
        const response = await fetch('/api/courses');
        const courses = await response.json();
        
        const featuredCourses = courses.slice(0, 3); // Show first 3 courses
        const container = document.getElementById('featured-courses');
        
        featuredCourses.forEach(course => {
            const courseCard = createCourseCard(course);
            container.appendChild(courseCard);
        });
    } catch (error) {
        console.error('Error loading courses:', error);
    }
}

// Load All Courses
async function loadAllCourses() {
    try {
        const response = await fetch('/api/courses');
        const courses = await response.json();
        
        const container = document.getElementById('courses-container');
        container.innerHTML = '';
        
        courses.forEach(course => {
            const courseCard = createCourseCard(course);
            container.appendChild(courseCard);
        });
    } catch (error) {
        console.error('Error loading courses:', error);
    }
}

// Create Course Card
function createCourseCard(course) {
    const card = document.createElement('div');
    card.className = 'course-card';
    card.dataset.category = course.category;
    card.dataset.level = course.level;
    
    card.innerHTML = `
        <div class="course-image">
            <i class="fas fa-laptop-code"></i>
        </div>
        <div class="course-content">
            <span class="course-category">${course.category}</span>
            <h3 class="course-title">${course.title}</h3>
            <p class="course-instructor">By ${course.instructor}</p>
            <p>${course.description.substring(0, 100)}...</p>
            <div class="course-meta">
                <div>
                    <div class="course-rating">
                        ${generateStars(course.rating)}
                        <span>(${course.rating})</span>
                    </div>
                    <div>${course.enrolled} enrolled</div>
                </div>
                <div class="course-price">$${course.price}</div>
            </div>
            <button class="btn-primary view-details" data-course-id="${course.id}">View Details</button>
        </div>
    `;
    
    return card;
}

// Generate Star Rating
function generateStars(rating) {
    let stars = '';
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 0; i < fullStars; i++) {
        stars += '<i class="fas fa-star"></i>';
    }
    
    if (hasHalfStar) {
        stars += '<i class="fas fa-star-half-alt"></i>';
    }
    
    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
        stars += '<i class="far fa-star"></i>';
    }
    
    return stars;
}

// Setup Course Filters
function setupCourseFilters() {
    const searchInput = document.getElementById('course-search');
    const categoryFilter = document.getElementById('category-filter');
    const levelFilter = document.getElementById('level-filter');
    
    const filterCourses = () => {
        const searchTerm = searchInput.value.toLowerCase();
        const category = categoryFilter.value;
        const level = levelFilter.value;
        
        const courseCards = document.querySelectorAll('.course-card');
        
        courseCards.forEach(card => {
            const title = card.querySelector('.course-title').textContent.toLowerCase();
            const cardCategory = card.dataset.category;
            const cardLevel = card.dataset.level;
            
            const matchesSearch = title.includes(searchTerm);
            const matchesCategory = !category || cardCategory === category;
            const matchesLevel = !level || cardLevel === level;
            
            if (matchesSearch && matchesCategory && matchesLevel) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    };
    
    searchInput.addEventListener('input', filterCourses);
    categoryFilter.addEventListener('change', filterCourses);
    levelFilter.addEventListener('change', filterCourses);
}

// Animate Stats Counter
function animateStats() {
    const statNumbers = document.querySelectorAll('.stat-number');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const statNumber = entry.target;
                const target = parseInt(statNumber.dataset.count);
                const duration = 2000; // 2 seconds
                const step = target / (duration / 16); // 60fps
                let current = 0;
                
                const timer = setInterval(() => {
                    current += step;
                    if (current >= target) {
                        current = target;
                        clearInterval(timer);
                    }
                    statNumber.textContent = Math.floor(current);
                }, 16);
                
                observer.unobserve(statNumber);
            }
        });
    }, { threshold: 0.5 });
    
    statNumbers.forEach(stat => observer.observe(stat));
}

// Setup Mobile Menu
function setupMobileMenu() {
    const mobileMenuBtn = document.querySelector('.mobile-menu');
    const navLinks = document.querySelector('.nav-links');
    
    if (mobileMenuBtn && navLinks) {
        mobileMenuBtn.addEventListener('click', () => {
            navLinks.style.display = navLinks.style.display === 'flex' ? 'none' : 'flex';
        });
        
        // Handle window resize
        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) {
                navLinks.style.display = 'flex';
            } else {
                navLinks.style.display = 'none';
            }
        });
    }
}

// Setup Course Modal
function setupCourseModal() {
    const modal = document.getElementById('course-modal');
    const closeBtn = document.querySelector('.close-modal');
    
    if (modal) {
        // Close modal when clicking X
        closeBtn.addEventListener('click', () => {
            modal.style.display = 'none';
        });
        
        // Close modal when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });
        
        // Handle view details buttons
        document.addEventListener('click', async (e) => {
            if (e.target.classList.contains('view-details')) {
                const courseId = e.target.dataset.courseId;
                await showCourseDetails(courseId);
            }
        });
    }
}

// Show Course Details
async function showCourseDetails(courseId) {
    try {
        const response = await fetch('/api/courses');
        const courses = await response.json();
        const course = courses.find(c => c.id == courseId);
        
        if (course) {
            const modal = document.getElementById('course-modal');
            const modalContent = document.getElementById('modal-course-details');
            
            modalContent.innerHTML = `
                <div class="course-details">
                    <h2>${course.title}</h2>
                    <div class="course-meta-details">
                        <span class="course-category">${course.category}</span>
                        <span><i class="fas fa-user"></i> ${course.instructor}</span>
                        <span><i class="fas fa-clock"></i> ${course.duration}</span>
                        <span><i class="fas fa-signal"></i> ${course.level}</span>
                        <span class="course-rating">${generateStars(course.rating)} (${course.rating})</span>
                    </div>
                    <div class="course-description">
                        <h3>Course Description</h3>
                        <p>${course.description}</p>
                    </div>
                    <div class="course-stats">
                        <div class="stat">
                            <i class="fas fa-users"></i>
                            <div>
                                <h4>${course.enrolled}</h4>
                                <p>Students Enrolled</p>
                            </div>
                        </div>
                        <div class="price-section">
                            <div class="course-price">$${course.price}</div>
                            ${sessionStorage.getItem('user_id') 
                                ? '<button class="btn-primary enroll-btn">Enroll Now</button>'
                                : '<a href="/login" class="btn-primary">Login to Enroll</a>'
                            }
                        </div>
                    </div>
                </div>
            `;
            
            modal.style.display = 'block';
            
            // Handle enroll button
            const enrollBtn = document.querySelector('.enroll-btn');
            if (enrollBtn) {
                enrollBtn.addEventListener('click', () => {
                    alert('Enrollment successful!');
                    modal.style.display = 'none';
                });
            }
        }
    } catch (error) {
        console.error('Error loading course details:', error);
    }
}