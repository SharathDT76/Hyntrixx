// Password toggle functionality
function togglePassword(inputId = 'password') {
    const passwordInput = document.getElementById(inputId);
    const toggleIcon = passwordInput.nextElementSibling;
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleIcon.classList.remove('fa-eye');
        toggleIcon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        toggleIcon.classList.remove('fa-eye-slash');
        toggleIcon.classList.add('fa-eye');
    }
}

// Password strength checker
function checkPasswordStrength(password) {
    let strength = 0;
    const strengthBar = document.querySelector('.strength-bar');
    const strengthText = document.querySelector('.strength-text');
    
    if (!password) {
        strengthBar.style.width = '0%';
        strengthBar.style.backgroundColor = '#ff4444';
        strengthText.textContent = 'Password strength: weak';
        return;
    }
    
    // Length check
    if (password.length >= 8) strength++;
    
    // Lowercase check
    if (/[a-z]/.test(password)) strength++;
    
    // Uppercase check
    if (/[A-Z]/.test(password)) strength++;
    
    // Number check
    if (/[0-9]/.test(password)) strength++;
    
    // Special character check
    if (/[^A-Za-z0-9]/.test(password)) strength++;
    
    // Update UI
    const width = strength * 20;
    strengthBar.style.width = width + '%';
    
    if (strength <= 2) {
        strengthBar.style.backgroundColor = '#ff4444';
        strengthText.textContent = 'Password strength: weak';
    } else if (strength <= 4) {
        strengthBar.style.backgroundColor = '#ffa726';
        strengthText.textContent = 'Password strength: medium';
    } else {
        strengthBar.style.backgroundColor = '#4CAF50';
        strengthText.textContent = 'Password strength: strong';
    }
}

// Form validation
function validateForm() {
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm_password').value;
    const passwordMatch = document.getElementById('password-match');
    const terms = document.getElementById('terms');
    
    // Check password match
    if (password !== confirmPassword) {
        passwordMatch.textContent = 'Passwords do not match!';
        passwordMatch.style.color = '#ff4444';
        return false;
    } else {
        passwordMatch.textContent = 'Passwords match!';
        passwordMatch.style.color = '#4CAF50';
    }
    
    // Check terms acceptance
    if (!terms.checked) {
        alert('Please accept the Terms & Conditions');
        return false;
    }
    
    return true;
}

// Real-time password strength checking
document.addEventListener('DOMContentLoaded', function() {
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirm_password');
    
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            checkPasswordStrength(this.value);
            
            // Check password match if confirm password exists
            if (confirmPasswordInput && confirmPasswordInput.value) {
                const passwordMatch = document.getElementById('password-match');
                if (this.value === confirmPasswordInput.value) {
                    passwordMatch.textContent = 'Passwords match!';
                    passwordMatch.style.color = '#4CAF50';
                } else {
                    passwordMatch.textContent = 'Passwords do not match!';
                    passwordMatch.style.color = '#ff4444';
                }
            }
        });
    }
    
    if (confirmPasswordInput) {
        confirmPasswordInput.addEventListener('input', function() {
            const password = document.getElementById('password').value;
            const passwordMatch = document.getElementById('password-match');
            
            if (password === this.value) {
                passwordMatch.textContent = 'Passwords match!';
                passwordMatch.style.color = '#4CAF50';
            } else {
                passwordMatch.textContent = 'Passwords do not match!';
                passwordMatch.style.color = '#ff4444';
            }
        });
    }
    
    // Social login buttons
    const googleBtn = document.querySelector('.btn-social.google');
    const githubBtn = document.querySelector('.btn-social.github');
    
    if (googleBtn) {
        googleBtn.addEventListener('click', function() {
            alert('Google login functionality would be implemented here');
        });
    }
    
    if (githubBtn) {
        githubBtn.addEventListener('click', function() {
            alert('GitHub login functionality would be implemented here');
        });
    }
});