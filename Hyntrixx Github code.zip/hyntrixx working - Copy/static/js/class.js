// Class Details Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Add click animation to topic cards
    const topicCards = document.querySelectorAll('.topic-card');
    
    topicCards.forEach(card => {
        card.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Add pulse animation
            this.classList.add('pulse');
            
            setTimeout(() => {
                this.classList.remove('pulse');
            }, 500);
            
            // Show quick preview
            const topicName = this.textContent.trim();
            showQuickPreview(topicName);
        });
    });
    
    // Quick preview function
    function showQuickPreview(topicName) {
        // Create toast preview
        const preview = document.createElement('div');
        preview.className = 'topic-preview';
        preview.innerHTML = `
            <div class="preview-content">
                <h4>${topicName}</h4>
                <p>This topic is available in your course curriculum.</p>
                <div class="preview-actions">
                    <button class="btn-preview" onclick="startLearning('${topicName}')">
                        <i class="fas fa-play"></i> Start Learning
                    </button>
                    <button class="btn-close" onclick="this.closest('.topic-preview').remove()">
                        Close
                    </button>
                </div>
            </div>
        `;
        
        // Add styles
        if (!document.querySelector('#preview-styles')) {
            const style = document.createElement('style');
            style.id = 'preview-styles';
            style.textContent = `
                .topic-preview {
                    position: fixed;
                    bottom: 20px;
                    right: 20px;
                    background: linear-gradient(135deg, #000, #333);
                    color: white;
                    padding: 1.5rem;
                    border-radius: 10px;
                    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
                    border-left: 4px solid #FFD700;
                    animation: slideUp 0.3s ease;
                    z-index: 10000;
                    max-width: 300px;
                }
                
                @keyframes slideUp {
                    from { transform: translateY(100%); opacity: 0; }
                    to { transform: translateY(0); opacity: 1; }
                }
                
                .preview-content h4 {
                    color: #FFD700;
                    margin-bottom: 0.5rem;
                }
                
                .preview-content p {
                    color: #ccc;
                    margin-bottom: 1rem;
                    font-size: 0.9rem;
                }
                
                .preview-actions {
                    display: flex;
                    gap: 0.5rem;
                }
                
                .btn-preview {
                    background: #FFD700;
                    color: #000;
                    border: none;
                    padding: 0.5rem 1rem;
                    border-radius: 4px;
                    cursor: pointer;
                    font-weight: 600;
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                }
                
                .btn-close {
                    background: rgba(255, 255, 255, 0.1);
                    color: white;
                    border: 1px solid rgba(255, 255, 255, 0.3);
                    padding: 0.5rem 1rem;
                    border-radius: 4px;
                    cursor: pointer;
                }
                
                .topic-card.pulse {
                    animation: pulse 0.5s ease;
                }
                
                @keyframes pulse {
                    0% { transform: scale(1); }
                    50% { transform: scale(1.05); background: #FFD700; color: #000; }
                    100% { transform: scale(1); }
                }
            `;
            document.head.appendChild(style);
        }
        
        // Remove existing preview
        const existingPreview = document.querySelector('.topic-preview');
        if (existingPreview) {
            existingPreview.remove();
        }
        
        document.body.appendChild(preview);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (preview.parentNode) {
                preview.remove();
            }
        }, 5000);
    }
    
    // Add progress tracking to class navigation
    const classLevel = window.location.pathname.match(/\/class\/(\d+)/);
    if (classLevel) {
        const level = classLevel[1];
        
        // Store visited classes in localStorage
        const visitedClasses = JSON.parse(localStorage.getItem('visitedClasses') || '[]');
        
        if (!visitedClasses.includes(level)) {
            visitedClasses.push(level);
            localStorage.setItem('visitedClasses', JSON.stringify(visitedClasses));
        }
        
        // Show progress on class buttons
        const classBtns = document.querySelectorAll('.class-btn');
        classBtns.forEach(btn => {
            const btnClass = btn.textContent.trim().replace('Class ', '');
            if (visitedClasses.includes(btnClass)) {
                btn.classList.add('visited');
                btn.innerHTML += ' ✓';
            }
        });
    }
});

// Start learning function (global)
window.startLearning = function(topicName) {
    alert(`Starting lesson: ${topicName}\nThis will redirect to the course player in the full version.`);
    
    // Close preview
    const preview = document.querySelector('.topic-preview');
    if (preview) {
        preview.remove();
    }
};

// Print syllabus
function printSyllabus() {
    window.print();
}

// Download syllabus as PDF
function downloadSyllabus() {
    const classLevel = document.querySelector('.class-header h1').textContent;
    const content = document.querySelector('.class-subjects').innerHTML;
    
    // In a real app, this would generate a PDF
    alert(`Syllabus for ${classLevel} will be downloaded as PDF.`);
}

// Share class page
function shareClass() {
    const classLevel = document.querySelector('.class-header h1').textContent;
    const url = window.location.href;
    
    if (navigator.share) {
        navigator.share({
            title: `Hyntrixx - ${classLevel}`,
            text: `Check out the curriculum for ${classLevel} at Hyntrixx!`,
            url: url
        }).catch(console.error);
    } else {
        // Fallback
        navigator.clipboard.writeText(url);
        alert('Link copied to clipboard!');
    }
}