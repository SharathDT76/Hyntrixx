// Dashboard JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all dashboard functionality
    
    // Progress circles animation
    initializeProgressCircles();
    
    // Setup user dropdown
    setupUserDropdown();
    
    // Setup mobile menu
    setupMobileMenu();
    
    // Setup chart filter
    setupChartFilter();
    
    // Setup notifications
    setupNotifications();
    
    // Setup course progress tracking
    setupCourseProgress();
});

function initializeProgressCircles() {
    const circles = document.querySelectorAll('.progress-circle');
    
    circles.forEach(circle => {
        const progress = parseInt(circle.dataset.progress);
        const circleElement = circle;
        
        // Animate the progress circle
        let currentProgress = 0;
        const interval = setInterval(() => {
            if (currentProgress >= progress) {
                clearInterval(interval);
                return;
            }
            
            currentProgress++;
            circleElement.style.background = 
                `conic-gradient(#FFD700 ${currentProgress}%, #e0e0e0 0%)`;
            circleElement.querySelector('span').textContent = `${currentProgress}%`;
        }, 20);
    });
}

function setupUserDropdown() {
    const userProfile = document.querySelector('.user-profile');
    const dropdown = document.querySelector('.dropdown-menu');
    
    if (userProfile && dropdown) {
        userProfile.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            dropdown.classList.toggle('show');
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.user-menu')) {
                dropdown.classList.remove('show');
            }
        });
    }
}

function setupMobileMenu() {
    const mobileMenuBtn = document.querySelector('.mobile-menu');
    const navLinks = document.querySelector('.nav-links');
    const sidebar = document.querySelector('.sidebar');
    
    if (mobileMenuBtn && navLinks) {
        mobileMenuBtn.addEventListener('click', function() {
            navLinks.classList.toggle('show');
        });
        
        // For mobile, toggle sidebar
        if (window.innerWidth <= 768 && sidebar) {
            mobileMenuBtn.addEventListener('click', function() {
                sidebar.classList.toggle('show');
            });
        }
    }
}

function setupChartFilter() {
    const filter = document.getElementById('progress-filter');
    
    if (filter) {
        filter.addEventListener('change', function() {
            const selectedValue = this.value;
            
            // Show loading state
            const chart = document.getElementById('progressChart');
            const ctx = chart.getContext('2d');
            
            // In a real application, you would fetch new data based on the filter
            // For now, we'll just log the selection
            console.log('Filter changed to:', selectedValue);
            
            // Show a toast notification
            showToast(`Showing data for ${selectedValue}`);
        });
    }
}

function setupNotifications() {
    const notificationBtn = document.querySelector('.btn-secondary');
    
    if (notificationBtn) {
        notificationBtn.addEventListener('click', function(e) {
            e.preventDefault();
            showNotificationsModal();
        });
    }
}

function showNotificationsModal() {
    // Create modal HTML
    const modalHTML = `
        <div class="modal-overlay">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Notifications</h3>
                    <button class="close-modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="notification-item unread">
                        <div class="notification-icon">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        <div class="notification-content">
                            <h4>Course Completed!</h4>
                            <p>Congratulations! You've completed "Python Programming"</p>
                            <span class="notification-time">2 hours ago</span>
                        </div>
                    </div>
                    <div class="notification-item unread">
                        <div class="notification-icon">
                            <i class="fas fa-comment-alt"></i>
                        </div>
                        <div class="notification-content">
                            <h4>New Reply</h4>
                            <p>Dr. Sarah replied to your question in "Machine Learning"</p>
                            <span class="notification-time">1 day ago</span>
                        </div>
                    </div>
                    <div class="notification-item">
                        <div class="notification-icon">
                            <i class="fas fa-calendar-alt"></i>
                        </div>
                        <div class="notification-content">
                            <h4>Upcoming Deadline</h4>
                            <p>Web Development project due in 3 days</p>
                            <span class="notification-time">2 days ago</span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn-mark-all">Mark All as Read</button>
                    <button class="btn-clear">Clear All</button>
                </div>
            </div>
        </div>
    `;
    
    // Add modal to body
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Add modal styles
    addModalStyles();
    
    // Setup modal interactions
    setupModalInteractions();
}

function addModalStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
        }
        
        .modal-content {
            background: white;
            border-radius: 10px;
            width: 90%;
            max-width: 500px;
            max-height: 80vh;
            overflow: hidden;
        }
        
        .modal-header {
            background: #000;
            color: white;
            padding: 1rem 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-header h3 {
            margin: 0;
            color: white;
        }
        
        .close-modal {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
        }
        
        .modal-body {
            padding: 1.5rem;
            max-height: 50vh;
            overflow-y: auto;
        }
        
        .notification-item {
            display: flex;
            gap: 1rem;
            padding: 1rem;
            border-bottom: 1px solid #eee;
            cursor: pointer;
        }
        
        .notification-item.unread {
            background: rgba(255, 215, 0, 0.1);
        }
        
        .notification-item:last-child {
            border-bottom: none;
        }
        
        .notification-icon {
            width: 40px;
            height: 40px;
            background: #FFD700;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #000;
            flex-shrink: 0;
        }
        
        .notification-content h4 {
            margin: 0 0 0.3rem 0;
            font-size: 1rem;
        }
        
        .notification-content p {
            margin: 0 0 0.5rem 0;
            color: #666;
            font-size: 0.9rem;
        }
        
        .notification-time {
            font-size: 0.8rem;
            color: #999;
        }
        
        .modal-footer {
            padding: 1rem 1.5rem;
            background: #f5f5f5;
            display: flex;
            justify-content: space-between;
        }
        
        .btn-mark-all, .btn-clear {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
        }
        
        .btn-mark-all {
            background: #FFD700;
            color: #000;
        }
        
        .btn-clear {
            background: #ff4444;
            color: white;
        }
    `;
    
    document.head.appendChild(style);
}

function setupModalInteractions() {
    const overlay = document.querySelector('.modal-overlay');
    const closeBtn = document.querySelector('.close-modal');
    const markAllBtn = document.querySelector('.btn-mark-all');
    const clearBtn = document.querySelector('.btn-clear');
    const notificationItems = document.querySelectorAll('.notification-item');
    
    // Close modal
    closeBtn.addEventListener('click', closeModal);
    overlay.addEventListener('click', function(e) {
        if (e.target === overlay) {
            closeModal();
        }
    });
    
    // Mark all as read
    markAllBtn.addEventListener('click', function() {
        notificationItems.forEach(item => {
            item.classList.remove('unread');
        });
        updateNotificationCount(0);
    });
    
    // Clear all notifications
    clearBtn.addEventListener('click', function() {
        if (confirm('Are you sure you want to clear all notifications?')) {
            notificationItems.forEach(item => item.remove());
            updateNotificationCount(0);
        }
    });
    
    // Mark individual notifications as read
    notificationItems.forEach(item => {
        item.addEventListener('click', function() {
            this.classList.remove('unread');
            const unreadCount = document.querySelectorAll('.notification-item.unread').length;
            updateNotificationCount(unreadCount);
        });
    });
    
    // Close modal with Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeModal();
        }
    });
}

function closeModal() {
    const modal = document.querySelector('.modal-overlay');
    if (modal) {
        modal.remove();
    }
}

function updateNotificationCount(count) {
    const notificationCount = document.querySelector('.notification-count');
    if (notificationCount) {
        notificationCount.textContent = count;
        if (count === 0) {
            notificationCount.style.display = 'none';
        } else {
            notificationCount.style.display = 'flex';
        }
    }
}

function setupCourseProgress() {
    const continueButtons = document.querySelectorAll('.btn-continue');
    
    continueButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Get course info
            const courseCard = this.closest('.course-card');
            const courseTitle = courseCard.querySelector('h3').textContent;
            
            // Show loading state
            const originalText = this.innerHTML;
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
            this.disabled = true;
            
            // Simulate loading
            setTimeout(() => {
                // Reset button
                this.innerHTML = originalText;
                this.disabled = false;
                
                // Show success message
                showToast(`Continuing with ${courseTitle}`);
                
                // In a real app, this would redirect to the course player
                // window.location.href = this.href;
            }, 1000);
        });
    });
}

function showToast(message, type = 'success') {
    // Remove existing toast
    const existingToast = document.querySelector('.toast');
    if (existingToast) {
        existingToast.remove();
    }
    
    // Create toast
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'}"></i>
            <span>${message}</span>
        </div>
        <button class="toast-close">&times;</button>
    `;
    
    // Add toast styles
    if (!document.querySelector('#toast-styles')) {
        const style = document.createElement('style');
        style.id = 'toast-styles';
        style.textContent = `
            .toast {
                position: fixed;
                bottom: 20px;
                right: 20px;
                background: white;
                border-left: 4px solid #FFD700;
                padding: 1rem 1.5rem;
                border-radius: 8px;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
                display: flex;
                align-items: center;
                justify-content: space-between;
                min-width: 300px;
                z-index: 10000;
                animation: slideIn 0.3s ease;
            }
            
            .toast-success {
                border-left-color: #4CAF50;
            }
            
            .toast-error {
                border-left-color: #ff4444;
            }
            
            .toast-content {
                display: flex;
                align-items: center;
                gap: 0.5rem;
            }
            
            .toast-content i {
                font-size: 1.2rem;
            }
            
            .toast-success .toast-content i {
                color: #4CAF50;
            }
            
            .toast-error .toast-content i {
                color: #ff4444;
            }
            
            .toast-close {
                background: none;
                border: none;
                font-size: 1.5rem;
                cursor: pointer;
                color: #666;
                padding: 0;
                width: 24px;
                height: 24px;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            @keyframes slideIn {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    document.body.appendChild(toast);
    
    // Setup close button
    const closeBtn = toast.querySelector('.toast-close');
    closeBtn.addEventListener('click', () => {
        toast.remove();
    });
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (toast.parentNode) {
            toast.remove();
        }
    }, 5000);
}

// Export functions if needed
window.dashboard = {
    showToast,
    closeModal,
    updateNotificationCount
};