// Index Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Audience Toggle with Tab Transition
    const kidsToggle = document.getElementById('kids-toggle');
    const collegeToggle = document.getElementById('college-toggle');
    const kidsSection = document.getElementById('kids-section');
    const collegeSection = document.getElementById('college-section');
    const audienceText = document.getElementById('audience-text');
    
    if (kidsToggle && collegeToggle) {
        kidsToggle.addEventListener('click', function() {
            // Toggle active states with animation
            kidsToggle.classList.add('active');
            collegeToggle.classList.remove('active');
            
            // Smooth tab transition
            kidsSection.style.display = 'block';
            collegeSection.style.display = 'none';
            
            // Trigger reflow for animation
            kidsSection.classList.remove('active');
            void kidsSection.offsetWidth;
            kidsSection.classList.add('active');
            
            // Update hero text
            audienceText.textContent = 'For Kids (1-10)';
            
            // Store preference
            localStorage.setItem('preferredAudience', 'kids');
        });
        
        collegeToggle.addEventListener('click', function() {
            // Toggle active states with animation
            collegeToggle.classList.add('active');
            kidsToggle.classList.remove('active');
            
            // Smooth tab transition
            collegeSection.style.display = 'block';
            kidsSection.style.display = 'none';
            
            // Trigger reflow for animation
            collegeSection.classList.remove('active');
            void collegeSection.offsetWidth;
            collegeSection.classList.add('active');
            
            // Update hero text
            audienceText.textContent = 'For College';
            
            // Store preference
            localStorage.setItem('preferredAudience', 'college');
        });
        
        // Check for stored preference
        const storedAudience = localStorage.getItem('preferredAudience');
        if (storedAudience === 'college') {
            collegeToggle.click();
        } else {
            kidsToggle.click(); // Default to kids
        }
    }
    
    
    const navbar = document.querySelector('.navbar');

    if (navbar) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 100) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });
    }

     

    // Tablet animation enhancement
    const tabletDevice = document.querySelector('.tablet-device');
    if (tabletDevice) {
        setInterval(() => {
            tabletDevice.classList.add('pulse');
            setTimeout(() => {
                tabletDevice.classList.remove('pulse');
            }, 500);
        }, 3000);
    }
    
    // Contact Form
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Simulate form submission
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
            submitBtn.disabled = true;
            
            setTimeout(() => {
                this.reset();
                showToast('Message sent successfully!', 'success');
                
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }, 1500);
        });
    }
    
    // Smooth scroll for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            if (href !== '#') {
                e.preventDefault();
                
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });
    
    // Mobile menu
    const mobileMenu = document.querySelector('.mobile-menu');
    const navLinks = document.querySelector('.nav-links');
    
    if (mobileMenu && navLinks) {
        mobileMenu.addEventListener('click', function() {
            navLinks.classList.toggle('show');
            this.classList.toggle('active');
        });
    }
    
    // Stats counter animation
    function animateStats() {
        const stats = document.querySelectorAll('.about-stats .stat h4');
        
        stats.forEach(stat => {
            const target = parseInt(stat.textContent.replace(/[^0-9]/g, ''));
            
            if (!isNaN(target) && target > 0) {
                let current = 0;
                const increment = target / 50;
                stat.textContent = '0+';
                
                const timer = setInterval(() => {
                    current += increment;
                    if (current >= target) {
                        stat.textContent = target + '+';
                        clearInterval(timer);
                    } else {
                        stat.textContent = Math.floor(current) + '+';
                    }
                }, 30);
            }
        });
    }
    
    // Animate stats when they come into view
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateStats();
                observer.disconnect();
            }
        });
    }, { threshold: 0.5 });
    
    const statsSection = document.querySelector('.about-stats');
    if (statsSection) {
        observer.observe(statsSection);
    }
    
    // Animate elements on scroll
    const animateElements = document.querySelectorAll('.feature-card, .course-card, .category-card');
    
    const scrollObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, { threshold: 0.2 });
    
    animateElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'all 0.6s cubic-bezier(0.165, 0.84, 0.44, 1)';
        scrollObserver.observe(el);
    });
});

// Show toast notification
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${message}</span>
        </div>
        <button class="toast-close">&times;</button>
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
    
    toast.querySelector('.toast-close').addEventListener('click', () => {
        toast.remove();
    });
}