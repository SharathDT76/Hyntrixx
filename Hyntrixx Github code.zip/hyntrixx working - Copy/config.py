import os
from datetime import timedelta

class Config:
    """Base configuration."""
    # Flask Configuration
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'your-secret-key-change-in-production'
    
    # Database Configuration
    basedir = os.path.abspath(os.path.dirname(__file__))
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or \
        'sqlite:///' + os.path.join(basedir, 'database.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Session Configuration
    PERMANENT_SESSION_LIFETIME = timedelta(days=7)
    SESSION_COOKIE_SECURE = False  # Set to True in production with HTTPS
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    
    # Security Configuration
    WTF_CSRF_ENABLED = True
    WTF_CSRF_SECRET_KEY = os.environ.get('CSRF_SECRET_KEY') or 'csrf-secret-key-change-me'
    
    # File Upload Configuration
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file upload
    UPLOAD_FOLDER = os.path.join(basedir, 'uploads')
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'pdf'}
    
    # Email Configuration
    MAIL_SERVER = os.environ.get('MAIL_SERVER') or 'smtp.gmail.com'
    MAIL_PORT = int(os.environ.get('MAIL_PORT') or 587)
    MAIL_USE_TLS = os.environ.get('MAIL_USE_TLS') or True
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME')
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD')
    MAIL_DEFAULT_SENDER = os.environ.get('MAIL_DEFAULT_SENDER') or 'noreply@hyntrixx.com'
    
    # Application Configuration
    APP_NAME = "Hyntrixx Technological and Educare Solutions"
    APP_VERSION = "1.0.0"
    DEBUG = os.environ.get('DEBUG', 'True') == 'True'
    TESTING = os.environ.get('TESTING', 'False') == 'True'


    # API Configuration
    API_PREFIX = '/api/v1'
    JSON_SORT_KEYS = False
    JSONIFY_PRETTYPRINT_REGULAR = True
    
    # Course Configuration
    COURSES_PER_PAGE = 12
    MAX_COURSE_DURATION = 52  # weeks
    MIN_COURSE_DURATION = 1   # week
    
    # User Configuration
    MIN_PASSWORD_LENGTH = 8
    MAX_PASSWORD_LENGTH = 128
    PASSWORD_RESET_TIMEOUT = 3600  # 1 hour in seconds
    
    # Cache Configuration
    CACHE_TYPE = 'simple'
    CACHE_DEFAULT_TIMEOUT = 300  # 5 minutes
    
    # Rate Limiting Configuration
    RATELIMIT_ENABLED = True
    RATELIMIT_STORAGE_URL = 'memory://'
    RATELIMIT_STRATEGY = 'fixed-window'
    RATELIMIT_DEFAULT = "200 per day;50 per hour"
    
    # Logging Configuration
    LOG_LEVEL = 'INFO'
    LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    
    # CORS Configuration (if needed for APIs)
    CORS_ORIGINS = [
        'http://localhost:5000',
        'http://127.0.0.1:5000',
        # Add production domains here
    ]
    
    # Payment Configuration (for future integration)
    STRIPE_PUBLIC_KEY = os.environ.get('STRIPE_PUBLIC_KEY') or ''
    STRIPE_SECRET_KEY = os.environ.get('STRIPE_SECRET_KEY') or ''
    
    # AWS Configuration (for future cloud storage)
    AWS_ACCESS_KEY_ID = os.environ.get('AWS_ACCESS_KEY_ID') or ''
    AWS_SECRET_ACCESS_KEY = os.environ.get('AWS_SECRET_ACCESS_KEY') or ''
    AWS_REGION = os.environ.get('AWS_REGION') or 'us-east-1'
    S3_BUCKET_NAME = os.environ.get('S3_BUCKET_NAME') or ''
    
    # Google OAuth Configuration (for future social login)
    GOOGLE_CLIENT_ID = os.environ.get('GOOGLE_CLIENT_ID') or ''
    GOOGLE_CLIENT_SECRET = os.environ.get('GOOGLE_CLIENT_SECRET') or ''
    
    # GitHub OAuth Configuration (for future social login)
    GITHUB_CLIENT_ID = os.environ.get('GITHUB_CLIENT_ID') or ''
    GITHUB_CLIENT_SECRET = os.environ.get('GITHUB_CLIENT_SECRET') or ''
    
    # Color Scheme Configuration (Yellow & Black Theme)
    COLOR_SCHEME = {
        'primary_yellow': '#FFD700',
        'dark_yellow': '#FFC107',
        'light_yellow': '#FFF9C4',
        'black': '#000000',
        'dark_gray': '#1a1a1a',
        'gray': '#666666',
        'light_gray': '#f5f5f5',
        'white': '#ffffff',
        'success': '#28a745',
        'danger': '#dc3545',
        'warning': '#ffc107',
        'info': '#17a2b8'
    }
    
    # Course Categories
    COURSE_CATEGORIES = [
        'Programming',
        'Data Science',
        'Web Development',
        'Mobile Development',
        'Cloud Computing',
        'Artificial Intelligence',
        'Machine Learning',
        'Cybersecurity',
        'Internet of Things',
        'Blockchain',
        'DevOps',
        'Software Engineering',
        'Database Management',
        'Game Development',
        'Embedded Systems',
        'Robotics',
        'Computer Networks',
        'Operating Systems',
        'Computer Architecture',
        'Digital Electronics'
    ]
    
    # Course Levels
    COURSE_LEVELS = ['Beginner', 'Intermediate', 'Advanced', 'Expert']
    
    # Education Domains
    ENGINEERING_BRANCHES = [
        'Computer Science',
        'Information Technology',
        'Electronics & Communication',
        'Electrical',
        'Mechanical',
        'Civil',
        'Chemical',
        'Biotechnology',
        'Aerospace',
        'Automobile'
    ]


class DevelopmentConfig(Config):
    """Development configuration."""
    DEBUG = True
    TESTING = False
    
    # Development-specific database
    SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(Config.basedir, 'dev_database.db')
    
    # Disable CSRF for easier API testing
    WTF_CSRF_ENABLED = False
    
    # Development email settings
    MAIL_SUPPRESS_SEND = True  # Don't actually send emails in dev
    
    # Enable detailed logging
    LOG_LEVEL = 'DEBUG'
    
    # Development CORS settings
    CORS_ORIGINS = ['*']  # Allow all in development
    
    # Rate limiting for development
    RATELIMIT_DEFAULT = "1000 per day;200 per hour"


class TestingConfig(Config):
    """Testing configuration."""
    TESTING = True
    DEBUG = True
    
    # Use in-memory SQLite for tests
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    
    # Disable CSRF for testing
    WTF_CSRF_ENABLED = False
    
    # Disable sending emails during tests
    MAIL_SUPPRESS_SEND = True
    
    # Test-specific configurations
    PRESERVE_CONTEXT_ON_EXCEPTION = False
    
    # Disable rate limiting in tests
    RATELIMIT_ENABLED = False
    
    # Test secret key
    SECRET_KEY = 'test-secret-key'


class ProductionConfig(Config):
    """Production configuration."""
    DEBUG = False
    TESTING = False
    
    # Production secret key (must be set as environment variable)
    SECRET_KEY = os.environ.get('SECRET_KEY')
    
    if not SECRET_KEY:
        raise ValueError("SECRET_KEY must be set in production environment")
    
    # Production database (PostgreSQL recommended)
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL')
    
    if not SQLALCHEMY_DATABASE_URI:
        raise ValueError("DATABASE_URL must be set in production environment")
    
    # Security settings for production
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Strict'
    
    # Enable CSRF protection in production
    WTF_CSRF_ENABLED = True
    
    # Production email settings
    MAIL_SERVER = os.environ.get('MAIL_SERVER')
    MAIL_PORT = int(os.environ.get('MAIL_PORT', 587))
    MAIL_USE_TLS = True
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME')
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD')
    
    # Production logging level
    LOG_LEVEL = 'WARNING'
    
    # Production rate limiting
    RATELIMIT_DEFAULT = "500 per day;100 per hour"
    
    # Production CORS - specify your domains
    CORS_ORIGINS = [
        'https://hyntrixx.com',
        'https://www.hyntrixx.com',
        # Add your production domain here
    ]
    
    # Production cache configuration (Redis recommended)
    CACHE_TYPE = 'redis'
    CACHE_REDIS_URL = os.environ.get('REDIS_URL') or 'redis://localhost:6379/0'
    CACHE_DEFAULT_TIMEOUT = 600  # 10 minutes


class StagingConfig(ProductionConfig):
    """Staging configuration."""
    DEBUG = True  # Keep debug on for staging
    
    # Staging-specific database
    SQLALCHEMY_DATABASE_URI = os.environ.get('STAGING_DATABASE_URL') or \
        'sqlite:///' + os.path.join(Config.basedir, 'staging_database.db')
    
    # Less restrictive security for staging
    SESSION_COOKIE_SECURE = False
    
    # Staging email settings
    MAIL_SUPPRESS_SEND = False  # Send emails in staging
    
    # Staging logging
    LOG_LEVEL = 'INFO'
    
    # Staging CORS
    CORS_ORIGINS = ['*']  # Allow all in staging for testing


# Configuration dictionary
config = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig,
    'staging': StagingConfig,
    'default': DevelopmentConfig
}


def get_config(config_name=None):
    """
    Get configuration based on environment variable or provided name.
    
    Args:
        config_name: Name of the configuration to load
        
    Returns:
        Configuration object
    """
    if config_name is None:
        config_name = os.environ.get('FLASK_ENV', 'default')
    
    return config.get(config_name, config['default'])


# Utility functions
def ensure_upload_folder():
    """Ensure upload folder exists."""
    if not os.path.exists(Config.UPLOAD_FOLDER):
        os.makedirs(Config.UPLOAD_FOLDER)


def allowed_file(filename):
    """Check if file extension is allowed."""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in Config.ALLOWED_EXTENSIONS


def get_color_scheme():
    """Get the color scheme for the application."""
    return Config.COLOR_SCHEME


def get_course_categories():
    """Get list of available course categories."""
    return Config.COURSE_CATEGORIES


def get_course_levels():
    """Get list of available course levels."""
    return Config.COURSE_LEVELS


def get_engineering_branches():
    """Get list of engineering branches."""
    return Config.ENGINEERING_BRANCHES