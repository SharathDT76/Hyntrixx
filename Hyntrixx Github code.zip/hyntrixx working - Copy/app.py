import os
from dotenv import load_dotenv

# Load environment variables FIRST
load_dotenv()

from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from config import get_config, ensure_upload_folder
from functools import wraps
from datetime import datetime, timedelta
from sqlalchemy import func

app = Flask(__name__)

# Load configuration
config_name = 'development'
app.config.from_object(get_config(config_name))

# Ensure upload folder exists
ensure_upload_folder()

# Initialize database
db = SQLAlchemy(app)


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash("Please login first.", "warning")
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


# Database Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, server_default=db.func.now())
    is_active = db.Column(db.Boolean, default=True)
    is_admin = db.Column(db.Boolean, default=False)
    user_type = db.Column(db.String(20), default='college')  # 'kids' or 'college'

class Course(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(100), nullable=False)
    subcategory = db.Column(db.String(100))
    subject = db.Column(db.String(100))
    duration = db.Column(db.String(50))
    level = db.Column(db.String(50))
    price = db.Column(db.Float)
    rating = db.Column(db.Float)
    enrolled = db.Column(db.Integer, default=0)
    target_audience = db.Column(db.String(50), default='college')
    class_level = db.Column(db.String(20))
    image_url = db.Column(db.String(200), default='default-course.jpg')

class Enrollment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'), nullable=False)
    enrolled_at = db.Column(db.DateTime, server_default=db.func.now())
    progress = db.Column(db.Float, default=0.0)
    certificate_issued = db.Column(db.Boolean, default=False)
    last_updated = db.Column(db.DateTime, nullable=True)


# Routes
@app.route('/')
def index():
    featured_kids_courses = Course.query.filter_by(
        target_audience='kids', 
        class_level='class-1'
    ).limit(4).all()
    
    featured_college_courses = Course.query.filter_by(
        target_audience='college'
    ).limit(6).all()
    
    return render_template('index.html',
                         featured_kids_courses=featured_kids_courses,
                         featured_college_courses=featured_college_courses)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        user = User.query.filter_by(email=email).first()

        if user and check_password_hash(user.password_hash, password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['user_type'] = user.user_type

            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))  # 🔥 FIXED HERE

        else:
            flash('Invalid email or password', 'danger')
            return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return redirect(url_for('register'))

        if User.query.filter_by(email=email).first():
            flash('Email already exists', 'danger')
            return redirect(url_for('register'))

        hashed_password = generate_password_hash(password)
        new_user = User(username=username, email=email, password_hash=hashed_password)

        db.session.add(new_user)
        db.session.commit()

        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')




@app.route('/dashboard')
@login_required
def dashboard():
    user = User.query.get(session['user_id'])
    enrollments = Enrollment.query.filter_by(user_id=user.id).all()
    
    # Total active courses
    active_courses = len(enrollments)

    # Total hours studied (example logic: 1 course = 10 hours * progress%)
    total_hours = sum((en.progress / 100) * 10 for en in enrollments)

    # Certificates earned
    certificates = Enrollment.query.filter_by(
        user_id=user.id,
        certificate_issued=True
    ).count()

    # Real streak logic (based on last_updated)
    activity_dates = db.session.query(
        func.date(Enrollment.last_updated)
    ).filter(
        Enrollment.user_id == user.id,
        Enrollment.last_updated != None
    ).distinct().all()

    activity_dates = [d[0] for d in activity_dates]

    streak = 0
    today = datetime.utcnow().date()

    while today in activity_dates:
        streak += 1
        today -= timedelta(days=1)

    # Chart data
    progress_data = [en.progress for en in enrollments]

    return render_template(
        'dashboard.html',
        user=user,
        username=session['username'],
        enrollments=enrollments,
        active_courses=active_courses,
        total_hours=round(total_hours, 1),
        certificates=certificates,
        streak=streak,
        progress_data=progress_data
    )



# Dashboard related routes
@app.route('/my-courses')
@login_required
def my_courses():
    user = User.query.get(session['user_id'])
    enrollments = Enrollment.query.filter_by(user_id=user.id).all()
    
    return render_template('my_courses.html',
                         enrollments=enrollments,
                         username=session['username'])
@app.route('/explore')
@login_required
def explore():
    if session.get('user_type') == 'kids':
        return redirect(url_for('kids_home'))
    return redirect(url_for('college_home'))


@app.route('/api/courses')
def api_courses():
    courses = Course.query.all()
    course_list = []
    for course in courses:
        course_list.append({
            'id': course.id,
            'title': course.title,
            'description': course.description,
            'category': course.category,
            'duration': course.duration,
            'level': course.level,
            'instructor': course.instructor,
            'price': course.price,
            'rating': course.rating,
            'enrolled': course.enrolled,
            'target_audience': course.target_audience
        })
    return jsonify(course_list)

@app.route('/logout')
def logout():
    session.clear()
    flash("Logged out successfully.", "info")
    return redirect(url_for('index'))




@app.route('/profile')
@login_required
def profile():
    user = User.query.get(session['user_id'])
    return render_template(
        'profile.html',
        user=user,
        username=session['username']
    )

@app.route('/progress')
@login_required
def progress():
    enrollments = Enrollment.query.filter_by(user_id=session['user_id']).all()
    total_progress = sum(enrollment.progress for enrollment in enrollments)
    avg_progress = total_progress / len(enrollments) if enrollments else 0
    
    return render_template('progress.html',
                         avg_progress=avg_progress,
                         enrollments=enrollments,
                         username=session['username'])

@app.route('/update-progress/<int:enrollment_id>', methods=['POST'])
@login_required
def update_progress(enrollment_id):
    enrollment = Enrollment.query.get_or_404(enrollment_id)

    # Security check
    if enrollment.user_id != session['user_id']:
        return jsonify({'error': 'Unauthorized'}), 403

    new_progress = float(request.form.get('progress', 0))
    enrollment.progress = new_progress
    enrollment.last_updated = datetime.utcnow()

    # Certificate auto-issue
    if enrollment.progress >= 100:
        enrollment.certificate_issued = True

    db.session.commit()

    return jsonify({'success': True})


@app.route('/certificates')
@login_required
def certificates():
    certificates = Enrollment.query.filter_by(
        user_id=session['user_id'],
        certificate_issued=True
    ).all()
    
    return render_template(
        'certificates.html',
        certificates=certificates,
        username=session['username']
    )

@app.route('/settings')
@login_required
def settings():
    return render_template('settings.html',
                         username=session['username'])

@app.route('/help')
def help():
    return render_template('help.html')

@app.route('/bookmarks')
@login_required
def bookmarks():
    return render_template('bookmarks.html',
                         username=session.get('username'))

@app.route('/pricing')
def pricing():
    return render_template('pricing.html',
                         username=session.get('username'))

@app.route('/kids')
@login_required
def kids_home():
    kids_courses = {}
    for class_level in range(1, 11):
        class_key = f'class-{class_level}'
        courses = Course.query.filter_by(
            target_audience='kids',
            class_level=class_key
        ).all()
        
        grouped_courses = {}
        for course in courses:
            if course.subject not in grouped_courses:
                grouped_courses[course.subject] = []
            grouped_courses[course.subject].append(course)
        
        kids_courses[class_key] = grouped_courses
    
    return render_template('kids.html', kids_courses=kids_courses)

@app.route('/college')
@login_required
def college_home():
    college_courses = Course.query.filter_by(target_audience='college').all()
    
    grouped_courses = {}
    for course in college_courses:
        if course.category not in grouped_courses:
            grouped_courses[course.category] = []
        grouped_courses[course.category].append(course)
    
    return render_template('college.html', college_courses=grouped_courses)

@app.route('/preuniversity')
def preuniversity():
    """Pre-University courses page."""
    return render_template('preuniversity.html')

@app.route('/jobs')
@login_required
def jobs():
    return render_template('jobs.html')

@app.route('/careers')
def careers():
    return "This will be added soon"

@app.route('/kids/class/<int:class_level>')
@login_required
def kids_class(class_level):
    if class_level < 1 or class_level > 10:
        return redirect(url_for('kids_home'))
    
    class_key = f'class-{class_level}'
    courses = Course.query.filter_by(
        target_audience='kids',
        class_level=class_key
    ).all()
    
    grouped_courses = {}
    for course in courses:
        if course.subject not in grouped_courses:
            grouped_courses[course.subject] = []
        grouped_courses[course.subject].append(course)
    
    return render_template('class_details.html',
                         class_level=class_level,
                         courses=grouped_courses)

@app.route('/college/course/<string:category>')
@login_required
def college_category(category):
    courses = Course.query.filter_by(
        target_audience='college',
        category=category
    ).all()
    
    return render_template('college_category.html',
                         category=category,
                         courses=courses)

def init_database():
    """Initialize database with kids and college courses."""
    with app.app_context():
        db.create_all()
        
        if Course.query.count() == 0:
            print("Adding sample courses...")
            
            # Kids Courses
            kids_courses = []
            
            # Class 1 Courses
            class_1_courses = [
                Course(
                    title="Two Little Hands",
                    description="Learn about body parts and basic English vocabulary",
                    category="English",
                    subject="English",
                    subcategory="Class 1 English",
                    class_level="class-1",
                    target_audience="kids",
                    level="Beginner",
                    instructor="Ms. Priya Sharma",
                    price=0.0,
                    rating=4.8,
                    enrolled=120,
                    image_url="english-class1.jpg"
                ),
                Course(
                    title="Greetings",
                    description="Learn basic greetings and daily conversations",
                    category="English",
                    subject="English",
                    subcategory="Class 1 English",
                    class_level="class-1",
                    target_audience="kids",
                    level="Beginner",
                    instructor="Ms. Priya Sharma",
                    price=0.0,
                    rating=4.7,
                    enrolled=115,
                    image_url="english-class1.jpg"
                ),
                Course(
                    title="Shapes and Space",
                    description="Introduction to basic shapes and spatial awareness",
                    category="Mathematics",
                    subject="Mathematics",
                    subcategory="Class 1 Mathematics",
                    class_level="class-1",
                    target_audience="kids",
                    level="Beginner",
                    instructor="Mr. Rajesh Kumar",
                    price=0.0,
                    rating=4.9,
                    enrolled=130,
                    image_url="math-class1.jpg"
                ),
            ]
            kids_courses.extend(class_1_courses)
            
            # College Courses
            college_courses = [
                Course(
                    title="Artificial Intelligence Fundamentals",
                    description="Introduction to AI concepts and applications with hands-on projects",
                    category="Artificial Intelligence",
                    target_audience="college",
                    level="Intermediate",
                    instructor="Dr. Sarah Johnson",
                    price=99.99,
                    rating=4.8,
                    enrolled=1250,
                    image_url="ai-course.jpg"
                ),
                Course(
                    title="Data Analytics with Python",
                    description="Learn data analysis techniques using Python libraries",
                    category="Data Analytics",
                    target_audience="college",
                    level="Intermediate",
                    instructor="Prof. Alex Chen",
                    price=89.99,
                    rating=4.7,
                    enrolled=980,
                    image_url="data-analytics.jpg"
                ),
                Course(
                    title="Machine Learning Masterclass",
                    description="Comprehensive ML algorithms and real-world applications",
                    category="Machine Learning",
                    target_audience="college",
                    level="Advanced",
                    instructor="Dr. Robert Kim",
                    price=149.99,
                    rating=4.9,
                    enrolled=850,
                    image_url="ml-course.jpg"
                ),
                Course(
                    title="Full Stack Web Development",
                    description="Build complete web applications with modern stack",
                    category="Full Stack Development",
                    target_audience="college",
                    level="Intermediate",
                    instructor="Mike Williams",
                    price=129.99,
                    rating=4.6,
                    enrolled=2100,
                    image_url="web-dev.jpg"
                ),
                Course(
                    title="Cloud Computing with AWS",
                    description="Learn cloud infrastructure and deployment strategies",
                    category="Cloud Computing",
                    target_audience="college",
                    level="Intermediate",
                    instructor="David Wilson",
                    price=119.99,
                    rating=4.8,
                    enrolled=920,
                    image_url="cloud.jpg"
                ),
                Course(
                    title="Cybersecurity Essentials",
                    description="Fundamentals of cybersecurity and threat protection",
                    category="Cyber Security",
                    target_audience="college",
                    level="Beginner",
                    instructor="Emily Davis",
                    price=79.99,
                    rating=4.5,
                    enrolled=750,
                    image_url="security.jpg"
                ),
                Course(
                    title="Mobile App Development with Flutter",
                    description="Build iOS and Android apps with Flutter framework",
                    category="Mobile App Development",
                    target_audience="college",
                    level="Intermediate",
                    instructor="John Parker",
                    price=109.99,
                    rating=4.7,
                    enrolled=680,
                    image_url="flutter.jpg"
                ),
                Course(
                    title="Data Science Bootcamp",
                    description="Complete data science course with real projects",
                    category="Data Science",
                    target_audience="college",
                    level="Advanced",
                    instructor="Dr. Lisa Wang",
                    price=159.99,
                    rating=4.9,
                    enrolled=1100,
                    image_url="data-science.jpg"
                )
            ]
            
            all_courses = kids_courses + college_courses
            db.session.add_all(all_courses)
            db.session.commit()
            print(f"Added {len(all_courses)} courses successfully!")

if __name__ == '__main__':
    init_database()
    
    port = int(os.environ.get('PORT', 5001))
    debug = app.config.get('DEBUG', False)
    
    print(f"\n{'='*60}")
    print(f"Starting Hyntrixx Technological and Educare Solutions")
    print(f"Environment: {config_name}")
    print(f"Debug mode: {debug}")
    print(f"Database: {app.config['SQLALCHEMY_DATABASE_URI']}")
    print(f"Server running at: http://localhost:{port}")
    print(f"{'='*60}\n")

    app.run(host='0.0.0.0', port=port, debug=debug)